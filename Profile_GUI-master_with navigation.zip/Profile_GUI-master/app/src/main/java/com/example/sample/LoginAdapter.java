package com.example.sample;

import android.content.Context;

import androidx.fragment.app.FragmentPagerAdapter;

//public class LoginAdapter extends FragmentPagerAdapter {
//
//
//
//}
